# Anonymous reproducibility supplement

Contents: all source code (phase0/, tests/, scripts/), all documentation
(docs/), the manuscript sources (paper/icaps27_unified/), and every saved
*analysis* output (aggregate statistics, means, comparisons, criteria) for
every campaign referenced in the manuscript, plus frozen-configuration files,
run manifests (software/hardware/seed provenance) and per-campaign raw-file
SHA-256 checksums.

NOT included (size): raw per-run trajectory files (results/**/runs/*.jsonl).
These total several hundred MB across all campaigns reported in this study,
exceeding the ICAPS-27 100MB supplementary-material limit. Their SHA-256
checksums ARE included (RUNS.sha256 in each campaign directory), so the
included analysis outputs are independently checkable against the raw files
without redistributing them in the capped bundle. The raw files are preserved
in the authors' private repository and will be deposited at a stable, anonymous
location (e.g. an anonymized OSF/Zenodo record) for the camera-ready version,
per ICAPS-27's own supplementary-material size limit (100MB, confirmed from
the CFP page 2026-11-23).

Reproduction: see docs/unified_icaps/01_baseline_verification.md through
08 (numbered in run order) for the full methodology, and
scripts/unified/run_confirmatory.sh / freeze_unified.py for the exact launch
commands. requirements_research.txt pins dependency versions.

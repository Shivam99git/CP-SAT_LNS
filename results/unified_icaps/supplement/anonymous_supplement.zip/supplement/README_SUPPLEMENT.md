# Anonymous reproducibility supplement

**Submission manuscript:** paper/icaps27_unified_final/manuscript_candidate.pdf
(this is the paper this supplement accompanies; paper/icaps27_unified/ is an
earlier, superseded draft kept for provenance, and paper/icaps27_iaip/ and
paper/icaps27_cobar/ -- the two still-earlier, independently-preserved
research stages -- are intentionally NOT included here to keep the bundle
focused on the submitted paper's own lineage; their code and data are the
same phase0/ code already included, so nothing about their claims is lost.)

Contents: all source code (phase0/, tests/, scripts/), all documentation
(docs/, including docs/final_icaps/ -- the final verification/audit phase),
the manuscript sources for both the submitted candidate and its immediate
predecessor draft, and every saved *analysis* output (aggregate statistics,
means, comparisons, criteria, the independent re-verification records, and
the machine-readable verified_metrics.json claim registry) for every campaign
referenced in the manuscript, plus frozen-configuration files, run manifests
(software/hardware/seed provenance), saved solver-log transcripts
(results/final_icaps/solver_logs/, demonstrating which CP-SAT subsolvers
actually ran under each configuration), and per-campaign raw-file SHA-256
checksums.

NOT included (size): raw per-run trajectory files (results/**/runs/*.jsonl).
These total several hundred MB across all campaigns reported in this study,
exceeding the ICAPS-27 100MB supplementary-material limit (re-confirmed
directly from the live CFP page on 2026-11-23: "the total size must not
exceed 100 MB", anonymization required, reviewers not obliged to read it).
Their SHA-256 checksums ARE included (RUNS.sha256 in each campaign
directory), so the included analysis outputs are independently checkable
against the raw files without redistributing them in the capped bundle. The
raw files are preserved in the authors' private repository and will be
deposited at a stable, anonymous location (e.g. an anonymized OSF/Zenodo
record) for the camera-ready version.

Reproduction: see docs/unified_icaps/01-08 and docs/final_icaps/01-08
(numbered in run order across the two phases) for the full methodology, and
scripts/unified/run_confirmatory.sh / freeze_unified.py and
scripts/final/verify_unified_confirmatory.py / build_verified_metrics.py for
the exact launch and independent-verification commands.
requirements_research.txt pins dependency versions.
